# AGENTS.md

## Scope

This repository contains an Android-focused Godot 4.4 client and a Python FastAPI gateway.

## Rules

- Keep the Android client free of API keys and server secrets.
- Use `user://workspace` for editable user projects.
- Do not add unrestricted absolute-path writes.
- Validate generated relative paths on both server and client.
- Preserve explicit user confirmation before applying generated files.
- Keep the Android preset name exactly `Android`; CI depends on it.
- The expected debug APK path is `build/android/GodotAICraft-debug.apk`.
- Run `pytest -q` in `server/` after backend changes.
- Do not claim an APK was built unless Godot export completed successfully.
