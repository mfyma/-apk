# معمارية Godot AI Craft Android

```text
Godot Android client
  ├─ Mobile RTL UI
  ├─ ChatGPT request mode
  ├─ Codex file-plan mode
  ├─ user://workspace editor
  └─ HTTPS client
          │
          ▼
FastAPI gateway
  ├─ Optional X-Client-Token verification
  ├─ Request/context limits
  ├─ OpenAI Responses API
  └─ Optional desktop-only Codex CLI endpoint
```

## حدود الثقة

- تطبيق Android لا يحتوي `OPENAI_API_KEY`.
- اتصال الإنتاج يجب أن يستخدم HTTPS.
- رمز `X-Client-Token` اختياري، ويحفظ محليًا في إعدادات التطبيق إذا أدخله المستخدم.
- الخادم يتحقق من مسارات الملفات التي يعيدها النموذج.
- العميل يتحقق من المسارات مرة ثانية قبل الكتابة داخل `user://workspace`.
- كل كتابة ملفات مولدة تحتاج تأكيدًا صريحًا داخل التطبيق.

## لماذا Codex CLI ليس داخل APK؟

Codex CLI يعتمد على بيئة نظام وعمليات فرعية ومساحة عمل وأدوات تطوير لا يوفرها تطبيق Android عادي. لذلك يستخدم العميل نمط `codex_plan` عبر الخادم، ويطبّق الملفات المولدة محليًا بعد مراجعة المستخدم.
