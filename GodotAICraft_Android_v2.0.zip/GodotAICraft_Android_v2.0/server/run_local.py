import os

import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host=os.getenv("AI_FORGE_HOST", "127.0.0.1"),
        port=int(os.getenv("AI_FORGE_PORT", "8765")),
        reload=os.getenv("AI_FORGE_RELOAD", "0") == "1",
    )
