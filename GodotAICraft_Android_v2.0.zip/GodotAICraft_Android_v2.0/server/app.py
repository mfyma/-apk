from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import secrets
from pathlib import Path
from typing import Literal

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()

APP_NAME = "Godot AI Craft Gateway"
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
DEFAULT_CHAT_MODEL = os.getenv("OPENAI_CHAT_MODEL", "gpt-5.6-terra")
DEFAULT_CODE_MODEL = os.getenv("OPENAI_CODE_MODEL", "gpt-5.6-sol")
CODEX_COMMAND = os.getenv("CODEX_COMMAND", "codex")
ALLOWED_ROOT = Path(os.getenv("AI_FORGE_ALLOWED_ROOT", str(Path.home()))).expanduser().resolve()
REQUEST_TIMEOUT_SECONDS = float(os.getenv("AI_FORGE_REQUEST_TIMEOUT", "600"))
MAX_CONTEXT_CHARS = int(os.getenv("AI_FORGE_MAX_CONTEXT_CHARS", "240000"))
CLIENT_TOKEN = os.getenv("AI_FORGE_CLIENT_TOKEN", "").strip()

app = FastAPI(title=APP_NAME, version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1", "http://localhost", "null"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-Client-Token"],
)


class ProjectContextFile(BaseModel):
    path: str = Field(min_length=1, max_length=2_000)
    content: str = Field(default="", max_length=1_000_000)


class AssistantRequest(BaseModel):
    mode: Literal["chatgpt", "codex_plan", "codex_cli"] = "chatgpt"
    prompt: str = Field(min_length=1, max_length=100_000)
    model: str = Field(default="", max_length=200)
    reasoning_effort: Literal["none", "low", "medium", "high", "xhigh", "max"] = "medium"
    workspace_path: str = ""
    allow_write: bool = False
    current_file: str = Field(default="", max_length=2_000)
    current_content: str = Field(default="", max_length=1_000_000)
    project_files: list[str] = Field(default_factory=list, max_length=500)
    project_context: list[ProjectContextFile] = Field(default_factory=list, max_length=80)


class GeneratedFile(BaseModel):
    path: str
    content: str


class AssistantResponse(BaseModel):
    reply: str
    files: list[GeneratedFile] = Field(default_factory=list)
    mode: str
    model: str


def verify_client_token(value: str) -> None:
    if CLIENT_TOKEN and not secrets.compare_digest(value, CLIENT_TOKEN):
        raise HTTPException(status_code=401, detail="رمز العميل غير صحيح.")


@app.get("/health")
async def health(x_client_token: str = Header(default="")) -> dict[str, object]:
    verify_client_token(x_client_token)
    return {
        "status": "ok",
        "service": APP_NAME,
        "codex_available": shutil.which(CODEX_COMMAND) is not None,
        "allowed_root": str(ALLOWED_ROOT),
    }


@app.post("/v1/assistant", response_model=AssistantResponse)
async def assistant(
    request: AssistantRequest,
    x_client_token: str = Header(default=""),
) -> AssistantResponse:
    verify_client_token(x_client_token)
    if request.mode == "codex_cli":
        return await run_codex_cli(request)

    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(
            status_code=503,
            detail="OPENAI_API_KEY غير مضبوط في ملف server/.env أو متغيرات البيئة.",
        )

    if request.mode == "codex_plan":
        model = request.model or DEFAULT_CODE_MODEL
        system_prompt = CODEX_PLAN_INSTRUCTIONS
    else:
        model = request.model or DEFAULT_CHAT_MODEL
        system_prompt = CHAT_INSTRUCTIONS

    user_input = build_user_input(request)
    raw_reply = await call_responses_api(
        api_key=api_key,
        model=model,
        instructions=system_prompt,
        user_input=user_input,
        reasoning_effort=request.reasoning_effort,
    )

    if request.mode == "codex_plan":
        parsed = parse_codex_plan(raw_reply)
        return AssistantResponse(
            reply=parsed["reply"],
            files=[GeneratedFile(**item) for item in parsed["files"]],
            mode=request.mode,
            model=model,
        )

    return AssistantResponse(reply=raw_reply, files=[], mode=request.mode, model=model)


CHAT_INSTRUCTIONS = """
أنت مساعد خبير في Godot 4 وGDScript وتصميم الألعاب. أجب بلغة المستخدم، وكن عمليًا ودقيقًا.
عند تقديم كود، استخدم Godot 4.4 أو أحدث ولا تدّعِ أنك شغّلت المشروع ما لم يُذكر ذلك صراحة.
لا تطلب مفاتيح سرية ولا تقترح وضع مفاتيح API داخل تطبيق العميل.
""".strip()

CODEX_PLAN_INSTRUCTIONS = """
أنت وكيل برمجة متخصص في إنشاء مشاريع وألعاب Godot 4 كاملة.
أعد JSON صالحًا فقط دون Markdown بالشكل التالي:
{
  "reply": "ملخص عربي واضح لما ستنشئه وأي افتراضات مهمة",
  "files": [
    {"path": "مسار نسبي آمن داخل المشروع", "content": "المحتوى الكامل للملف"}
  ]
}
قواعد إلزامية:
- الملفات يجب أن تكون كاملة وليست مقتطفات.
- استخدم مسارات نسبية فقط، بلا .. وبلا مسارات مطلقة.
- لا تضع أسرارًا أو مفاتيح API.
- استخدم Godot 4.4+ وGDScript حديثًا.
- حافظ على الملفات الموجودة عندما لا يلزم استبدالها.
- اجعل الرد قابلًا للتطبيق مباشرة، وضمّن project.godot والمشاهد والسكربتات اللازمة إذا كان الطلب مشروعًا جديدًا.
""".strip()


def build_user_input(request: AssistantRequest) -> str:
    sections = [f"طلب المستخدم:\n{request.prompt.strip()}"]
    if request.project_files:
        safe_files = [item[:500] for item in request.project_files[:500]]
        sections.append("ملفات المشروع الحالية:\n" + "\n".join(f"- {item}" for item in safe_files))
    if request.project_context:
        context_sections: list[str] = []
        remaining = MAX_CONTEXT_CHARS - sum(len(section) for section in sections)
        for item in request.project_context[:80]:
            if remaining <= 0:
                break
            if not is_safe_relative_path(item.path):
                continue
            block = f"ملف: {item.path}\n```\n{item.content}\n```"
            if len(block) > remaining:
                break
            context_sections.append(block)
            remaining -= len(block)
        if context_sections:
            sections.append("محتوى ملفات المشروع الحالية:\n" + "\n\n".join(context_sections))
    elif request.current_file:
        content = request.current_content[:MAX_CONTEXT_CHARS]
        sections.append(f"الملف المفتوح: {request.current_file}\nالمحتوى:\n```\n{content}\n```")
    return "\n\n".join(sections)[:MAX_CONTEXT_CHARS]


async def call_responses_api(
    *,
    api_key: str,
    model: str,
    instructions: str,
    user_input: str,
    reasoning_effort: str,
) -> str:
    payload: dict[str, object] = {
        "model": model,
        "instructions": instructions,
        "input": user_input,
        "max_output_tokens": 32_000,
    }
    if reasoning_effort != "none":
        payload["reasoning"] = {"effort": reasoning_effort}

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    try:
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS) as client:
            response = await client.post(f"{OPENAI_BASE_URL}/responses", headers=headers, json=payload)
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"تعذر الاتصال بـ OpenAI: {exc}") from exc

    if response.status_code >= 400:
        detail = response.text
        try:
            error_data = response.json()
            detail = error_data.get("error", {}).get("message", detail)
        except ValueError:
            pass
        raise HTTPException(status_code=502, detail=f"OpenAI API: {detail}")

    data = response.json()
    output_text = extract_output_text(data)
    if not output_text:
        raise HTTPException(status_code=502, detail="لم تُرجع OpenAI نصًا قابلًا للقراءة.")
    return output_text


def extract_output_text(data: dict[str, object]) -> str:
    direct = data.get("output_text")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()

    fragments: list[str] = []
    output = data.get("output", [])
    if isinstance(output, list):
        for item in output:
            if not isinstance(item, dict):
                continue
            content = item.get("content", [])
            if not isinstance(content, list):
                continue
            for part in content:
                if not isinstance(part, dict):
                    continue
                text = part.get("text")
                if isinstance(text, str) and text:
                    fragments.append(text)
    return "\n".join(fragments).strip()


def parse_codex_plan(text: str) -> dict[str, object]:
    candidate = text.strip()
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", candidate, re.DOTALL)
    if fenced:
        candidate = fenced.group(1)
    else:
        start = candidate.find("{")
        end = candidate.rfind("}")
        if start >= 0 and end > start:
            candidate = candidate[start : end + 1]

    try:
        data = json.loads(candidate)
    except json.JSONDecodeError:
        return {"reply": text, "files": []}

    reply = str(data.get("reply", "تم إنشاء خطة ملفات."))
    valid_files: list[dict[str, str]] = []
    files = data.get("files", [])
    if isinstance(files, list):
        for item in files[:100]:
            if not isinstance(item, dict):
                continue
            path = str(item.get("path", "")).replace("\\", "/").strip()
            content = item.get("content", "")
            if not isinstance(content, str) or not is_safe_relative_path(path):
                continue
            valid_files.append({"path": path, "content": content})
    return {"reply": reply, "files": valid_files}


def is_safe_relative_path(path: str) -> bool:
    if not path or path.startswith(("/", "\\")) or ":" in path:
        return False
    parts = Path(path).parts
    return ".." not in parts and "." not in parts


def resolve_workspace(path_value: str) -> Path:
    if not path_value:
        raise HTTPException(status_code=400, detail="لم يُرسل مسار مساحة العمل.")
    candidate = Path(path_value).expanduser().resolve()
    try:
        candidate.relative_to(ALLOWED_ROOT)
    except ValueError as exc:
        raise HTTPException(
            status_code=403,
            detail=f"المسار خارج AI_FORGE_ALLOWED_ROOT: {ALLOWED_ROOT}",
        ) from exc
    if not candidate.is_dir():
        raise HTTPException(status_code=400, detail="مساحة العمل غير موجودة أو ليست مجلدًا.")
    return candidate


async def run_codex_cli(request: AssistantRequest) -> AssistantResponse:
    executable = shutil.which(CODEX_COMMAND)
    if executable is None:
        raise HTTPException(
            status_code=503,
            detail="Codex CLI غير مثبت أو غير موجود في PATH. استخدم وضع Codex للاقتراحات أو ثبّت Codex CLI.",
        )

    workspace = resolve_workspace(request.workspace_path)
    model = request.model or DEFAULT_CODE_MODEL
    sandbox = "workspace-write" if request.allow_write else "read-only"
    prompt = request.prompt.strip()
    if request.current_file:
        prompt += f"\n\nالملف المفتوح حاليًا: {request.current_file}"
    if request.project_files:
        prompt += "\n\nملفات المشروع:\n" + "\n".join(request.project_files[:300])

    command = [
        executable,
        "exec",
        "--cd",
        str(workspace),
        "--model",
        model,
        "--sandbox",
        sandbox,
        "--ask-for-approval",
        "never",
        "--skip-git-repo-check",
        "--color",
        "never",
        prompt,
    ]

    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(workspace),
        )
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=REQUEST_TIMEOUT_SECONDS)
    except asyncio.TimeoutError as exc:
        process.kill()
        await process.wait()
        raise HTTPException(status_code=504, detail="انتهت مهلة Codex CLI.") from exc
    except OSError as exc:
        raise HTTPException(status_code=502, detail=f"تعذر تشغيل Codex CLI: {exc}") from exc

    stdout_text = stdout.decode("utf-8", errors="replace").strip()
    stderr_text = stderr.decode("utf-8", errors="replace").strip()
    if process.returncode != 0:
        raise HTTPException(
            status_code=502,
            detail=f"Codex CLI خرج بالرمز {process.returncode}: {stderr_text or stdout_text}",
        )

    reply = stdout_text or "اكتمل Codex CLI دون إخراج نصي."
    if stderr_text:
        reply += f"\n\nملاحظات التشغيل:\n{stderr_text}"
    return AssistantResponse(reply=reply, files=[], mode=request.mode, model=model)
