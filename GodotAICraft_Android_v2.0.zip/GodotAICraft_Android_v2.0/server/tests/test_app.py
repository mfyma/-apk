from app import (
    AssistantRequest,
    ProjectContextFile,
    build_user_input,
    extract_output_text,
    is_safe_relative_path,
    parse_codex_plan,
)


def test_extract_output_text_from_response_items() -> None:
    payload = {
        "output": [
            {
                "type": "message",
                "content": [
                    {"type": "output_text", "text": "hello"},
                    {"type": "output_text", "text": "world"},
                ],
            }
        ]
    }
    assert extract_output_text(payload) == "hello\nworld"


def test_parse_codex_plan_filters_unsafe_paths() -> None:
    result = parse_codex_plan(
        """```json
        {"reply":"ok","files":[
          {"path":"scripts/player.gd","content":"extends Node"},
          {"path":"../secret.txt","content":"bad"},
          {"path":"C:/secret.txt","content":"bad"}
        ]}
        ```"""
    )
    assert result["reply"] == "ok"
    assert result["files"] == [{"path": "scripts/player.gd", "content": "extends Node"}]


def test_safe_relative_paths() -> None:
    assert is_safe_relative_path("scenes/main.tscn")
    assert not is_safe_relative_path("../main.tscn")
    assert not is_safe_relative_path("/tmp/main.tscn")
    assert not is_safe_relative_path("C:/tmp/main.tscn")


def test_build_user_input_includes_safe_project_context() -> None:
    request = AssistantRequest(
        prompt="راجع المشروع",
        project_context=[
            ProjectContextFile(path="scripts/player.gd", content="extends CharacterBody2D"),
            ProjectContextFile(path="../secret.txt", content="should not appear"),
            ProjectContextFile(path="project.godot", content="config_version=5"),
        ],
    )
    result = build_user_input(request)
    assert "scripts/player.gd" in result
    assert "extends CharacterBody2D" in result
    assert "../secret.txt" not in result
    assert "project.godot" in result


def test_build_user_input_falls_back_to_open_file() -> None:
    request = AssistantRequest(
        prompt="اشرح الملف",
        current_file="main.gd",
        current_content="extends Node",
    )
    result = build_user_input(request)
    assert "main.gd" in result
    assert "extends Node" in result
