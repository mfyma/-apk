# Godot AI Craft — تطبيق Android لصناعة ألعاب Godot بمساعدة ChatGPT وCodex

تطبيق Godot 4 مهيأ للهواتف والأجهزة اللوحية. يوفّر محادثة برمجية، وإنشاء ملفات مشروع Godot كاملة، ومحرر ملفات داخل التطبيق، مع خادم وسيط يحمي مفتاح OpenAI من الاستخراج من ملف APK.

> **مهم:** ملف APK هو عميل للهاتف، وليس خادم OpenAI. يجب نشر مجلد `server/` على خادم HTTPS وضبط عنوانه من صفحة الإعدادات داخل التطبيق. وضع مفتاح OpenAI داخل APK خطأ أمني واضح، لذلك المشروع لا يفعل ذلك.

## الوظائف

- واجهة عربية عمودية ومهيأة للمس.
- وضع **ChatGPT** لشرح GDScript وتصميم أنظمة اللعب وحل الأخطاء.
- وضع **Codex — إنشاء ملفات** يعيد ملفات كاملة، ثم يطلب تأكيدًا قبل كتابتها.
- مساحة عمل داخل بيانات التطبيق: `user://workspace`.
- مستعرض ملفات، محرر نصوص، إنشاء ملفات وحفظها ونسخها.
- إرسال محتوى ملفات المشروع إلى المساعد اختياريًا كسياق.
- إنشاء نسخة ZIP من مساحة العمل داخل `user://exports`.
- إعداد مستقل لنموذج المحادثة ونموذج البرمجة.
- رمز وصول اختياري بين التطبيق والخادم عبر `X-Client-Token`.
- GitHub Actions لاختبار الخادم وبناء Debug APK ورفعه كـArtifact.

## بنية المشروع

```text
GodotAICraft/
├── assets/
│   └── icon.svg
├── scenes/
│   └── Main.tscn
├── scripts/
│   └── main.gd
├── server/
│   ├── app.py
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── requirements-dev.txt
│   ├── .env.example
│   └── tests/
├── .github/workflows/build.yml
├── project.godot
├── export_presets.cfg
├── BUILD_STATUS.md
└── README.md
```

## المعمارية الأمنية

```text
Android APK (Godot)
  ├─ واجهة ChatGPT
  ├─ مخطط ملفات Codex
  ├─ محرر مساحة العمل
  └─ HTTPS + X-Client-Token اختياري
                  │
                  ▼
        FastAPI Gateway على خادمك
                  │
                  ▼
          OpenAI Responses API
```

- `OPENAI_API_KEY` موجود على الخادم فقط.
- التطبيق يرفض عناوين HTTP العامة؛ ويقبل HTTP المحلي فقط أثناء التطوير.
- مسارات الملفات الناتجة تُفحص لمنع المسارات المطلقة و`..`.
- ملفات Codex لا تُكتب إلا بعد تأكيد المستخدم.
- رمز العميل ليس بديلًا عن HTTPS، بل طبقة وصول إضافية بسيطة.

## تشغيل الخادم محليًا

```bash
cd server
python -m venv .venv
source .venv/bin/activate          # Linux/macOS
# .venv\Scripts\activate           # Windows
pip install -r requirements.txt
cp .env.example .env
```

حرّر `server/.env`:

```dotenv
OPENAI_API_KEY=ضع_المفتاح_على_الخادم_فقط
AI_FORGE_CLIENT_TOKEN=قيمة_طويلة_وعشوائية
OPENAI_CHAT_MODEL=gpt-5.6-terra
OPENAI_CODE_MODEL=gpt-5.6-sol
```

ثم شغّل:

```bash
uvicorn app:app --host 0.0.0.0 --port 8765
```

للتجربة من هاتف على الشبكة المحلية، أدخل في التطبيق عنوان الحاسوب، مثل:

```text
http://192.168.1.20:8765
```

للاستخدام خارج الشبكة المحلية يجب نشر الخادم خلف **HTTPS**.

## تشغيل الخادم باستخدام Docker

```bash
cd server
docker build -t godot-ai-craft-gateway .
docker run --rm -p 8765:8765 --env-file .env godot-ai-craft-gateway
```

## بناء APK محليًا

المتطلبات:

- Godot 4.4.1 مع Android Export Templates.
- JDK 17.
- Android SDK مضبوط داخل إعدادات Godot.

من جذر المشروع:

```bash
mkdir -p build/android
godot --headless --path . --export-debug Android build/android/GodotAICraft-debug.apk
```

المسار المتوقع:

```text
build/android/GodotAICraft-debug.apk
```

## البناء التلقائي على GitHub

الملف `.github/workflows/build.yml` ينفذ الآتي:

1. يشغّل اختبارات Python.
2. يفحص مشروع Godot وGDScript بوضع Headless.
3. ينشئ Debug Keystore مؤقتًا داخل بيئة CI.
4. يصدّر `GodotAICraft-debug.apk`.
5. يرفع APK وملف SHA-256 كـArtifact باسم `GodotAICraft-debug-apk`.

بعد رفع المشروع إلى GitHub افتح:

```text
Actions → Build Godot AI Craft Android → Run workflow
```

ثم حمّل الـArtifact من صفحة التشغيل الناجح.

## حدود النسخة الحالية

- التطبيق **ينشئ ويحرر مصدر مشروع Godot**، لكنه لا يشغّل Godot Editor أو Android SDK داخل الهاتف، لذلك لا يبني لعبة المستخدم إلى APK من داخل APK نفسه.
- Codex CLI لا يعمل داخل تطبيق Android عادي. وضع Codex في التطبيق يستخدم الخادم لإنشاء خطة ملفات كاملة ثم يطبقها بعد التأكيد.
- ZIP يُحفظ داخل مساحة بيانات التطبيق. نسخ الملفات إلى تطبيقات أخرى يعتمد على قيود نظام Android ومدير الملفات في الجهاز.
- يحتاج التطبيق اتصالًا بخادمك؛ من دون خادم مضبوط ستعمل أدوات تحرير الملفات فقط.

## الاختبارات

```bash
cd server
pip install -r requirements-dev.txt
pytest -q
```

راجع `BUILD_STATUS.md` لمعرفة ما تم تشغيله فعليًا في بيئة إعداد الحزمة.

## الترخيص

MIT — راجع `LICENSE`.
