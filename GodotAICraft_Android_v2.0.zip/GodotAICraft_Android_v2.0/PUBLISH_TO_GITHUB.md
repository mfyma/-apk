# رفع المشروع إلى GitHub وبناء APK

تعذر الرفع الآلي سابقًا لأن GitHub App أعاد الخطأ `403 Resource not accessible by integration` عند محاولة الكتابة إلى `mfyma/-apk`. الموصل كان يملك القراءة فقط، لا صلاحية **Contents: write**.

بعد منح صلاحية الكتابة، ارفع المشروع:

```bash
git init
git add .
git commit -m "Add Godot AI Craft Android"
git branch -M main
git remote add origin https://github.com/mfyma/-apk.git
git push -u origin main
```

يفضل إعادة تسمية المستودع إلى `Godot-AI-Craft-Android`.

بعد الرفع:

1. افتح تبويب **Actions**.
2. اختر **Build Godot AI Craft Android**.
3. اضغط **Run workflow**.
4. بعد نجاح التشغيل حمّل Artifact باسم `GodotAICraft-debug-apk`.

ملف APK داخل الـArtifact:

```text
build/android/GodotAICraft-debug.apk
```
