# حالة البناء

## ما تم التحقق منه محليًا

- اختبارات خادم Python.
- فحص بنية الملفات والمسارات الحساسة.
- وجود إعداد تصدير Android باسم `Android`.
- وجود GitHub Actions لبناء Debug APK ورفعه كـArtifact.

## ما لم يُبنَ محليًا

بيئة إعداد المشروع الحالية لا تحتوي Godot Editor ولا Android SDK، لذلك لم يتم إنشاء APK محليًا ولم يُدّعَ ذلك.

## أمر البناء المتوقع

```bash
godot --headless --path . --export-debug Android build/android/GodotAICraft-debug.apk
```

## ملف APK المتوقع

```text
build/android/GodotAICraft-debug.apk
```
