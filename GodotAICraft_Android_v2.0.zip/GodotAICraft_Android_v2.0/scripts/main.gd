extends Control

const APP_TITLE := "Godot AI Craft"
const APP_VERSION := "2.0.0-android"
const SETTINGS_PATH := "user://settings.cfg"
const WORKSPACE_PATH := "user://workspace"
const EXPORTS_PATH := "user://exports"
const DEFAULT_BACKEND := "https://your-backend.example.com"
const DEFAULT_CHAT_MODEL := "gpt-5.6-terra"
const DEFAULT_CODE_MODEL := "gpt-5.6-sol"
const MAX_FILE_BYTES := 750_000
const MAX_CONTEXT_FILES := 40
const MAX_CONTEXT_CHARS := 150_000
const TEXT_EXTENSIONS := [
	"gd", "tscn", "tres", "godot", "cfg", "ini", "json", "txt", "md", "csv",
	"xml", "yaml", "yml", "toml", "shader", "gdshader", "cs", "cpp", "h", "hpp",
	"py", "js", "ts", "html", "css", "sql", "sh", "bat", "ps1"
]
const IGNORED_DIRS := [".git", ".godot", ".import", "build", "dist", "__pycache__", ".venv", "venv"]

var workspace_path := ""
var current_file_path := ""
var pending_files: Array = []
var is_requesting := false
var request_kind := "assistant"
var settings := ConfigFile.new()
var file_paths: Array[String] = []

var tabs: TabContainer
var chat_log: RichTextLabel
var prompt_editor: TextEdit
var mode_selector: OptionButton
var send_button: Button
var apply_button: Button
var status_label: Label
var file_list: ItemList
var current_file_label: Label
var code_editor: CodeEdit
var save_file_button: Button
var backend_input: LineEdit
var token_input: LineEdit
var chat_model_input: LineEdit
var code_model_input: LineEdit
var context_check: CheckBox
var http_request: HTTPRequest
var new_file_dialog: ConfirmationDialog
var new_file_input: LineEdit
var apply_dialog: ConfirmationDialog

func _ready() -> void:
	workspace_path = ProjectSettings.globalize_path(WORKSPACE_PATH)
	DirAccess.make_dir_recursive_absolute(workspace_path)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(EXPORTS_PATH))
	_load_settings()
	_create_starter_workspace_if_empty()
	_build_theme()
	_build_ui()
	_refresh_files()
	_append_assistant("مرحبًا بك في Godot AI Craft للهاتف. اختر ChatGPT للأسئلة أو Codex لإنشاء ملفات لعبة كاملة، ثم راجع الملفات قبل تطبيقها.")
	_set_status("جاهز — الإصدار %s" % APP_VERSION)

func _build_theme() -> void:
	var app_theme := Theme.new()
	app_theme.default_font_size = 18
	theme = app_theme

func _build_ui() -> void:
	layout_direction = Control.LAYOUT_DIRECTION_RTL
	var safe_margin := MarginContainer.new()
	safe_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	safe_margin.add_theme_constant_override("margin_left", 10)
	safe_margin.add_theme_constant_override("margin_top", 10)
	safe_margin.add_theme_constant_override("margin_right", 10)
	safe_margin.add_theme_constant_override("margin_bottom", 10)
	add_child(safe_margin)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	safe_margin.add_child(root)

	var header := HBoxContainer.new()
	header.custom_minimum_size.y = 54
	root.add_child(header)
	var title := Label.new()
	title.text = "🎮  %s" % APP_TITLE
	title.add_theme_font_size_override("font_size", 22)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var health_button := _touch_button("اختبار الخادم")
	health_button.pressed.connect(_test_backend)
	header.add_child(health_button)

	tabs = TabContainer.new()
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tabs.tab_alignment = TabBar.ALIGNMENT_CENTER
	root.add_child(tabs)
	_build_chat_tab()
	_build_files_tab()
	_build_settings_tab()

	status_label = Label.new()
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.custom_minimum_size.y = 34
	root.add_child(status_label)

	http_request = HTTPRequest.new()
	http_request.timeout = 180.0
	http_request.request_completed.connect(_on_http_request_completed)
	add_child(http_request)

	new_file_dialog = ConfirmationDialog.new()
	new_file_dialog.title = "إنشاء ملف داخل مساحة العمل"
	new_file_dialog.ok_button_text = "إنشاء"
	new_file_dialog.cancel_button_text = "إلغاء"
	new_file_dialog.confirmed.connect(_create_new_file)
	add_child(new_file_dialog)
	var dialog_box := VBoxContainer.new()
	dialog_box.custom_minimum_size = Vector2(340, 110)
	new_file_dialog.add_child(dialog_box)
	var help := Label.new()
	help.text = "اكتب مسارًا نسبيًا، مثال: scripts/player.gd"
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dialog_box.add_child(help)
	new_file_input = LineEdit.new()
	new_file_input.placeholder_text = "scripts/new_script.gd"
	new_file_input.text_submitted.connect(func(_value: String) -> void: _create_new_file())
	dialog_box.add_child(new_file_input)

	apply_dialog = ConfirmationDialog.new()
	apply_dialog.title = "تأكيد تطبيق ملفات Codex"
	apply_dialog.ok_button_text = "تطبيق"
	apply_dialog.cancel_button_text = "إلغاء"
	apply_dialog.confirmed.connect(_apply_pending_files)
	add_child(apply_dialog)

func _build_chat_tab() -> void:
	var chat_tab := VBoxContainer.new()
	chat_tab.name = "المساعد"
	chat_tab.add_theme_constant_override("separation", 8)
	tabs.add_child(chat_tab)

	var mode_row := HBoxContainer.new()
	chat_tab.add_child(mode_row)
	var mode_label := Label.new()
	mode_label.text = "الوضع:"
	mode_row.add_child(mode_label)
	mode_selector = OptionButton.new()
	mode_selector.add_item("ChatGPT — سؤال وشرح", 0)
	mode_selector.add_item("Codex — إنشاء ملفات", 1)
	mode_selector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mode_selector.item_selected.connect(_on_mode_changed)
	mode_row.add_child(mode_selector)
	context_check = CheckBox.new()
	context_check.text = "سياق المشروع"
	context_check.button_pressed = true
	mode_row.add_child(context_check)

	chat_log = RichTextLabel.new()
	chat_log.bbcode_enabled = true
	chat_log.scroll_active = true
	chat_log.scroll_following = true
	chat_log.selection_enabled = true
	chat_log.size_flags_vertical = Control.SIZE_EXPAND_FILL
	chat_log.custom_minimum_size.y = 280
	chat_tab.add_child(chat_log)

	prompt_editor = TextEdit.new()
	prompt_editor.custom_minimum_size.y = 150
	prompt_editor.placeholder_text = "مثال: أنشئ لعبة منصات 2D كاملة فيها لاعب وأعداء ونقاط..."
	prompt_editor.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	chat_tab.add_child(prompt_editor)

	var actions := HBoxContainer.new()
	chat_tab.add_child(actions)
	send_button = _touch_button("إرسال")
	send_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	send_button.pressed.connect(_send_prompt)
	actions.add_child(send_button)
	apply_button = _touch_button("تطبيق الملفات")
	apply_button.disabled = true
	apply_button.visible = false
	apply_button.pressed.connect(_confirm_apply_pending_files)
	actions.add_child(apply_button)
	var clear_button := _touch_button("مسح")
	clear_button.pressed.connect(func() -> void: chat_log.clear())
	actions.add_child(clear_button)

func _build_files_tab() -> void:
	var files_tab := VBoxContainer.new()
	files_tab.name = "الملفات"
	files_tab.add_theme_constant_override("separation", 8)
	tabs.add_child(files_tab)

	var file_actions := HBoxContainer.new()
	files_tab.add_child(file_actions)
	var refresh_button := _touch_button("تحديث")
	refresh_button.pressed.connect(_refresh_files)
	file_actions.add_child(refresh_button)
	var new_button := _touch_button("ملف جديد")
	new_button.pressed.connect(_show_new_file_dialog)
	file_actions.add_child(new_button)
	save_file_button = _touch_button("حفظ")
	save_file_button.disabled = true
	save_file_button.pressed.connect(_save_current_file)
	file_actions.add_child(save_file_button)
	var copy_button := _touch_button("نسخ الكود")
	copy_button.pressed.connect(_copy_current_file)
	file_actions.add_child(copy_button)
	var zip_button := _touch_button("ZIP")
	zip_button.pressed.connect(_export_workspace_zip)
	file_actions.add_child(zip_button)

	var split := VSplitContainer.new()
	split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	split.split_offset = 250
	files_tab.add_child(split)
	file_list = ItemList.new()
	file_list.custom_minimum_size.y = 180
	file_list.item_selected.connect(_on_file_selected)
	split.add_child(file_list)
	var editor_box := VBoxContainer.new()
	split.add_child(editor_box)
	current_file_label = Label.new()
	current_file_label.text = "لا يوجد ملف مفتوح"
	current_file_label.text_direction = Control.TEXT_DIRECTION_LTR
	editor_box.add_child(current_file_label)
	code_editor = CodeEdit.new()
	code_editor.layout_direction = Control.LAYOUT_DIRECTION_LTR
	code_editor.text_direction = Control.TEXT_DIRECTION_LTR
	code_editor.size_flags_vertical = Control.SIZE_EXPAND_FILL
	code_editor.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	code_editor.placeholder_text = "اختر ملفًا نصيًا من القائمة..."
	code_editor.editable = false
	code_editor.text_changed.connect(_on_editor_changed)
	editor_box.add_child(code_editor)

func _build_settings_tab() -> void:
	var settings_scroll := ScrollContainer.new()
	settings_scroll.name = "الإعدادات"
	tabs.add_child(settings_scroll)
	var settings_box := VBoxContainer.new()
	settings_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings_box.add_theme_constant_override("separation", 12)
	settings_scroll.add_child(settings_box)

	var warning := Label.new()
	warning.text = "لا تضع مفتاح OpenAI داخل التطبيق. أدخل عنوان خادمك الآمن فقط."
	warning.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	warning.add_theme_font_size_override("font_size", 19)
	settings_box.add_child(warning)

	backend_input = _setting_line(settings_box, "عنوان الخادم HTTPS", str(settings.get_value("network", "backend_url", DEFAULT_BACKEND)), "https://api.example.com")
	token_input = _setting_line(settings_box, "رمز العميل الاختياري", str(settings.get_value("network", "client_token", "")), "X-Client-Token")
	token_input.secret = true
	chat_model_input = _setting_line(settings_box, "نموذج ChatGPT", str(settings.get_value("models", "chat", DEFAULT_CHAT_MODEL)), DEFAULT_CHAT_MODEL)
	code_model_input = _setting_line(settings_box, "نموذج Codex", str(settings.get_value("models", "code", DEFAULT_CODE_MODEL)), DEFAULT_CODE_MODEL)

	var buttons := HBoxContainer.new()
	settings_box.add_child(buttons)
	var save_button := _touch_button("حفظ الإعدادات")
	save_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	save_button.pressed.connect(_save_settings)
	buttons.add_child(save_button)
	var test_button := _touch_button("اختبار الاتصال")
	test_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	test_button.pressed.connect(_test_backend)
	buttons.add_child(test_button)

	var info := Label.new()
	info.text = "مساحة العمل محفوظة داخل بيانات التطبيق. زر ZIP ينشئ نسخة في user://exports، ويمكنك أيضًا نسخ كل ملف إلى الحافظة."
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	settings_box.add_child(info)

func _touch_button(text: String) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size.y = 50
	return button

func _setting_line(parent: VBoxContainer, label_text: String, value: String, placeholder: String) -> LineEdit:
	var label := Label.new()
	label.text = label_text
	parent.add_child(label)
	var input := LineEdit.new()
	input.text = value
	input.placeholder_text = placeholder
	input.layout_direction = Control.LAYOUT_DIRECTION_LTR
	input.text_direction = Control.TEXT_DIRECTION_LTR
	input.custom_minimum_size.y = 52
	parent.add_child(input)
	return input

func _load_settings() -> void:
	var error := settings.load(SETTINGS_PATH)
	if error != OK and error != ERR_FILE_NOT_FOUND:
		push_warning("تعذر تحميل الإعدادات: %s" % error_string(error))

func _save_settings() -> void:
	var backend := backend_input.text.strip_edges().trim_suffix("/")
	if not backend.begins_with("https://") and not _is_local_debug_url(backend):
		_set_status("استخدم HTTPS. يُسمح بـHTTP فقط للعناوين المحلية أثناء التطوير.")
		return
	settings.set_value("network", "backend_url", backend)
	settings.set_value("network", "client_token", token_input.text.strip_edges())
	settings.set_value("models", "chat", chat_model_input.text.strip_edges())
	settings.set_value("models", "code", code_model_input.text.strip_edges())
	var error := settings.save(SETTINGS_PATH)
	_set_status("تم حفظ الإعدادات" if error == OK else "فشل حفظ الإعدادات: %s" % error_string(error))

func _on_mode_changed(index: int) -> void:
	apply_button.visible = index == 1
	if index == 0:
		apply_button.disabled = true
	else:
		apply_button.disabled = pending_files.is_empty()

func _send_prompt() -> void:
	if is_requesting:
		return
	var prompt := prompt_editor.text.strip_edges()
	if prompt.is_empty():
		_set_status("اكتب طلبًا أولًا")
		return
	_save_settings()
	var backend := _backend_url()
	if backend.is_empty():
		return
	if not save_file_button.disabled:
		_save_current_file()
	var mode := "chatgpt" if mode_selector.selected == 0 else "codex_plan"
	var payload := {
		"mode": mode,
		"prompt": prompt,
		"model": chat_model_input.text.strip_edges() if mode == "chatgpt" else code_model_input.text.strip_edges(),
		"reasoning_effort": "medium",
		"workspace_path": "",
		"allow_write": false,
		"current_file": _relative_path(current_file_path),
		"current_content": code_editor.text if not current_file_path.is_empty() else "",
		"project_files": _collect_project_paths() if context_check.button_pressed else [],
		"project_context": _collect_project_context() if context_check.button_pressed else []
	}
	_append_user(prompt)
	prompt_editor.text = ""
	pending_files.clear()
	apply_button.disabled = true
	is_requesting = true
	request_kind = "assistant"
	send_button.disabled = true
	_set_status("جاري الاتصال بالمساعد...")
	var headers := _request_headers(true)
	var error := http_request.request(backend + "/v1/assistant", headers, HTTPClient.METHOD_POST, JSON.stringify(payload))
	if error != OK:
		_finish_request("تعذر بدء الطلب: %s" % error_string(error))

func _test_backend() -> void:
	if is_requesting:
		return
	_save_settings()
	var backend := _backend_url()
	if backend.is_empty():
		return
	is_requesting = true
	request_kind = "health"
	send_button.disabled = true
	_set_status("جاري اختبار الخادم...")
	var error := http_request.request(backend + "/health", _request_headers(false))
	if error != OK:
		_finish_request("تعذر بدء الاختبار: %s" % error_string(error))

func _backend_url() -> String:
	var backend := backend_input.text.strip_edges().trim_suffix("/")
	if backend.is_empty() or backend.contains("your-backend.example.com"):
		tabs.current_tab = 2
		_set_status("أدخل عنوان خادمك في الإعدادات أولًا")
		return ""
	if not backend.begins_with("https://") and not _is_local_debug_url(backend):
		tabs.current_tab = 2
		_set_status("عنوان الخادم يجب أن يستخدم HTTPS")
		return ""
	return backend

func _is_local_debug_url(url: String) -> bool:
	return url.begins_with("http://127.0.0.1") or url.begins_with("http://localhost") or url.begins_with("http://10.") or url.begins_with("http://192.168.")

func _request_headers(json_body: bool) -> PackedStringArray:
	var headers := PackedStringArray()
	if json_body:
		headers.append("Content-Type: application/json")
	var token := token_input.text.strip_edges()
	if not token.is_empty():
		headers.append("X-Client-Token: %s" % token)
	return headers

func _on_http_request_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var raw := body.get_string_from_utf8()
	if result != HTTPRequest.RESULT_SUCCESS:
		_finish_request("فشل الاتصال بالخادم. النتيجة: %d" % result)
		return
	var parsed = JSON.parse_string(raw)
	if response_code < 200 or response_code >= 300:
		var detail := raw
		if typeof(parsed) == TYPE_DICTIONARY and parsed.has("detail"):
			detail = str(parsed["detail"])
		_finish_request("خطأ من الخادم (%d): %s" % [response_code, detail])
		return
	if request_kind == "health":
		_append_assistant("الخادم متصل ويعمل.")
		_finish_request("تم الاتصال بالخادم بنجاح")
		return
	if typeof(parsed) != TYPE_DICTIONARY:
		_finish_request("استجابة غير صالحة من الخادم")
		return
	var reply := str(parsed.get("reply", "تمت العملية دون رسالة."))
	_append_assistant(reply)
	var files_value = parsed.get("files", [])
	if typeof(files_value) == TYPE_ARRAY:
		for file_info in files_value:
			if typeof(file_info) == TYPE_DICTIONARY and file_info.has("path") and file_info.has("content"):
				pending_files.append(file_info)
	if not pending_files.is_empty():
		apply_button.visible = true
		apply_button.disabled = false
		_append_assistant("Codex اقترح %d ملف/ملفات. راجع الرد ثم اضغط «تطبيق الملفات»." % pending_files.size())
	_finish_request("اكتمل الطلب")

func _finish_request(message: String) -> void:
	is_requesting = false
	send_button.disabled = false
	_set_status(message)

func _confirm_apply_pending_files() -> void:
	if pending_files.is_empty():
		return
	apply_dialog.dialog_text = "سيتم إنشاء أو استبدال %d ملف/ملفات داخل مساحة عمل التطبيق. هل تريد المتابعة؟" % pending_files.size()
	apply_dialog.popup_centered(Vector2i(390, 260))

func _apply_pending_files() -> void:
	var written := 0
	var rejected: Array[String] = []
	for file_info in pending_files:
		var relative := str(file_info.get("path", ""))
		var target := _safe_workspace_target(relative)
		if target.is_empty():
			rejected.append(relative)
			continue
		DirAccess.make_dir_recursive_absolute(target.get_base_dir())
		var file := FileAccess.open(target, FileAccess.WRITE)
		if file == null:
			rejected.append(relative)
			continue
		file.store_string(str(file_info.get("content", "")))
		written += 1
	pending_files.clear()
	apply_button.disabled = true
	_refresh_files()
	tabs.current_tab = 1
	_append_assistant("تمت كتابة %d ملف/ملفات.%s" % [written, " رُفضت مسارات غير آمنة: " + ", ".join(rejected) if not rejected.is_empty() else ""])
	_set_status("تم تطبيق ملفات Codex")

func _refresh_files() -> void:
	if file_list == null:
		return
	file_list.clear()
	file_paths.clear()
	_collect_file_paths_recursive(workspace_path, workspace_path, file_paths, 0)
	file_paths.sort()
	for relative in file_paths:
		file_list.add_item(relative)
	_set_status("عدد ملفات مساحة العمل: %d" % file_paths.size())

func _collect_file_paths_recursive(root: String, path: String, output: Array[String], depth: int) -> void:
	if depth > 18:
		return
	var dir := DirAccess.open(path)
	if dir == null:
		return
	var entries: Array[String] = []
	dir.list_dir_begin()
	var name := dir.get_next()
	while not name.is_empty():
		entries.append(name)
		name = dir.get_next()
	dir.list_dir_end()
	entries.sort()
	for entry in entries:
		if entry in IGNORED_DIRS:
			continue
		var full := path.path_join(entry)
		if DirAccess.dir_exists_absolute(full):
			_collect_file_paths_recursive(root, full, output, depth + 1)
		elif _is_text_file(full):
			output.append(full.trim_prefix(root).trim_prefix("/"))

func _on_file_selected(index: int) -> void:
	if index < 0 or index >= file_paths.size():
		return
	_open_text_file(workspace_path.path_join(file_paths[index]))

func _open_text_file(path: String) -> void:
	if not FileAccess.file_exists(path) or not _is_text_file(path):
		_set_status("تعذر فتح الملف")
		return
	if FileAccess.get_file_as_bytes(path).size() > MAX_FILE_BYTES:
		_set_status("الملف أكبر من حد المعاينة")
		return
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		_set_status("فشل فتح الملف")
		return
	current_file_path = path
	code_editor.text = file.get_as_text()
	code_editor.editable = true
	current_file_label.text = _relative_path(path)
	save_file_button.disabled = true
	_set_status("تم فتح %s" % _relative_path(path))

func _on_editor_changed() -> void:
	if not current_file_path.is_empty():
		save_file_button.disabled = false

func _save_current_file() -> void:
	if current_file_path.is_empty():
		return
	var file := FileAccess.open(current_file_path, FileAccess.WRITE)
	if file == null:
		_set_status("فشل حفظ الملف")
		return
	file.store_string(code_editor.text)
	save_file_button.disabled = true
	_set_status("تم حفظ %s" % _relative_path(current_file_path))

func _copy_current_file() -> void:
	if current_file_path.is_empty():
		_set_status("اختر ملفًا أولًا")
		return
	DisplayServer.clipboard_set(code_editor.text)
	_set_status("تم نسخ محتوى الملف إلى الحافظة")

func _show_new_file_dialog() -> void:
	new_file_input.text = ""
	new_file_dialog.popup_centered(Vector2i(380, 260))
	new_file_input.grab_focus()

func _create_new_file() -> void:
	var relative := new_file_input.text.strip_edges().replace("\\", "/")
	var target := _safe_workspace_target(relative)
	if target.is_empty():
		_set_status("المسار غير صالح")
		return
	if FileAccess.file_exists(target):
		_set_status("الملف موجود مسبقًا")
		return
	DirAccess.make_dir_recursive_absolute(target.get_base_dir())
	var file := FileAccess.open(target, FileAccess.WRITE)
	if file == null:
		_set_status("فشل إنشاء الملف")
		return
	file.store_string(_default_content_for(relative))
	new_file_dialog.hide()
	_refresh_files()
	_open_text_file(target)

func _default_content_for(path: String) -> String:
	match path.get_extension().to_lower():
		"gd":
			return "extends Node\n\nfunc _ready() -> void:\n\tpass\n"
		"tscn":
			return "[gd_scene format=3]\n\n[node name=\"Root\" type=\"Node\"]\n"
		"json":
			return "{}\n"
		_:
			return ""

func _collect_project_paths() -> Array[String]:
	var paths: Array[String] = []
	_collect_file_paths_recursive(workspace_path, workspace_path, paths, 0)
	if paths.size() > MAX_CONTEXT_FILES:
		paths.resize(MAX_CONTEXT_FILES)
	return paths

func _collect_project_context() -> Array[Dictionary]:
	var context: Array[Dictionary] = []
	var total_chars := 0
	var paths := _collect_project_paths()
	for relative in paths:
		var full := workspace_path.path_join(relative)
		var bytes := FileAccess.get_file_as_bytes(full)
		if bytes.size() > MAX_FILE_BYTES:
			continue
		var text := bytes.get_string_from_utf8()
		if total_chars + text.length() > MAX_CONTEXT_CHARS:
			break
		context.append({"path": relative, "content": text})
		total_chars += text.length()
	return context

func _export_workspace_zip() -> void:
	var stamp := Time.get_datetime_string_from_system(false, true).replace(":", "-")
	var relative_zip := "%s/GodotProject-%s.zip" % [EXPORTS_PATH, stamp]
	var packer := ZIPPacker.new()
	var error := packer.open(relative_zip)
	if error != OK:
		_set_status("فشل إنشاء ZIP: %s" % error_string(error))
		return
	var paths: Array[String] = []
	_collect_all_workspace_files(workspace_path, workspace_path, paths, 0)
	for relative in paths:
		var full := workspace_path.path_join(relative)
		if packer.start_file(relative) != OK:
			continue
		packer.write_file(FileAccess.get_file_as_bytes(full))
		packer.close_file()
	packer.close()
	var absolute := ProjectSettings.globalize_path(relative_zip)
	DisplayServer.clipboard_set(absolute)
	_set_status("تم إنشاء ZIP ونسخ مساره: %s" % absolute)

func _collect_all_workspace_files(root: String, path: String, output: Array[String], depth: int) -> void:
	if depth > 18:
		return
	var dir := DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	var name := dir.get_next()
	while not name.is_empty():
		if name in IGNORED_DIRS:
			name = dir.get_next()
			continue
		var full := path.path_join(name)
		if DirAccess.dir_exists_absolute(full):
			_collect_all_workspace_files(root, full, output, depth + 1)
		else:
			output.append(full.trim_prefix(root).trim_prefix("/"))
		name = dir.get_next()
	dir.list_dir_end()

func _safe_workspace_target(relative: String) -> String:
	var clean := relative.strip_edges().replace("\\", "/")
	if clean.is_empty() or clean.begins_with("/") or clean.contains("..") or clean.contains(":"):
		return ""
	var target := workspace_path.path_join(clean).simplify_path()
	var root := workspace_path.simplify_path().trim_suffix("/") + "/"
	if not target.begins_with(root):
		return ""
	return target

func _relative_path(path: String) -> String:
	if path.is_empty():
		return ""
	return path.trim_prefix(workspace_path).trim_prefix("/")

func _is_text_file(path: String) -> bool:
	return path.get_extension().to_lower() in TEXT_EXTENSIONS

func _append_user(text: String) -> void:
	chat_log.append_text("\n[color=#7DB7FF][b]أنت[/b][/color]\n%s\n" % _escape_bbcode(text))

func _append_assistant(text: String) -> void:
	chat_log.append_text("\n[color=#68E0C1][b]المساعد[/b][/color]\n%s\n" % _escape_bbcode(text))

func _escape_bbcode(text: String) -> String:
	return text.replace("[", "[lb]")

func _set_status(text: String) -> void:
	if status_label != null:
		status_label.text = text

func _create_starter_workspace_if_empty() -> void:
	var dir := DirAccess.open(workspace_path)
	if dir == null:
		return
	dir.list_dir_begin()
	var first := dir.get_next()
	dir.list_dir_end()
	if not first.is_empty():
		return
	_write_starter_file("project.godot", "; Starter project generated by Godot AI Craft Mobile\nconfig_version=5\n\n[application]\nconfig/name=\"My AI Game\"\nrun/main_scene=\"res://main.tscn\"\n\n[display]\nwindow/size/viewport_width=960\nwindow/size/viewport_height=540\n\n[rendering]\nrenderer/rendering_method=\"gl_compatibility\"\n")
	_write_starter_file("main.tscn", "[gd_scene load_steps=2 format=3]\n\n[ext_resource type=\"Script\" path=\"res://main.gd\" id=\"1\"]\n\n[node name=\"Main\" type=\"Node2D\"]\nscript = ExtResource(\"1\")\n")
	_write_starter_file("main.gd", "extends Node2D\n\nfunc _ready() -> void:\n\tprint(\"Starter project ready\")\n")
	_write_starter_file("README.md", "# My AI Game\n\nهذه مساحة عمل أولية. اطلب من Codex إنشاء مشاهد وسكربتات اللعبة.\n")

func _write_starter_file(relative: String, content: String) -> void:
	var target := workspace_path.path_join(relative)
	DirAccess.make_dir_recursive_absolute(target.get_base_dir())
	var file := FileAccess.open(target, FileAccess.WRITE)
	if file != null:
		file.store_string(content)
